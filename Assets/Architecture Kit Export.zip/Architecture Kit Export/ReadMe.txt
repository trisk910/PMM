Hey! Thanks for downloading the PSX Architecture Kit asset pack
Made by: Comp-3 Interactive


Creating your own textures is very simple, the walls, ceilings and floors are all unwrapped to a square (or half square for the 1.5m pieces) so you just need to simply create a new image file with your texture, I suggest 256x256 pixels for that crunch old school look
<< License Agreements >>
- You CAN modify the assets
- You CAN use these assets in commercial projects
- You CAN NOT redistribute or resale, even if modified




Follow Comp-3 Interactive on Twitter for game and asset updates!
https://twitter.com/comp3int
If you like this pack then please remember to rate!